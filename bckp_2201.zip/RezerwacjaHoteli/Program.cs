﻿using Microsoft.EntityFrameworkCore;
using RezerwacjaHoteli.Data;
using RezerwacjaHoteli.Models;
using System.Security.Cryptography;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<HotelReservationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


builder.Services.AddControllersWithViews();

builder.Services.AddSession();



var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseRouting();
app.UseSession();



app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<HotelReservationDbContext>();
    context.Database.Migrate();
    SeedData(context);
}

app.Run();

void SeedData(HotelReservationDbContext context)
{
    if (context.Users.Any())
    {
        return;
    }

    // Testowi użytkownicy
    var adminPassword = "Admin123!";
    var guestPassword = "Guest123!";

    var users = new List<User>
    {
        new User
        {
            Email = "admin@hotel.com",
            PasswordHash = adminPassword,
            FullName = "Admin",
            PhoneNumber = "123456789",
            Role = "Admin",
            CreatedDate = DateTime.Now
        },
        new User
        {
            Email = "guest@example.com",
            PasswordHash = guestPassword,
            FullName = "Guest",
            PhoneNumber = "987654321",
            Role = "Guest",
            CreatedDate = DateTime.Now
        }
    };

    context.Users.AddRange(users);
    context.SaveChanges();

    var hotels = new List<Hotel>
    {
        new Hotel
        {
            Name = "Grand Warsaw Hotel",
            Address = "ul. Żwirki i Wigury 16A",
            City = "Warszawa",
            StarRating = 5,
            Description = "Luksusowy hotel w centrum miasta",
            ContactEmail = "info@grand.com",
            IsActive = true,
            CreatedDate = DateTime.Now
        },
        new Hotel
        {
            Name = "Grand Krakow Hotel",
            Address = "ul. Kapelanka 42B",
            City = "Kraków",
            StarRating = 4,
            Description = "Hotel idealny na spotkania biznesowe",
            ContactEmail = "info@grand.com",
            IsActive = true,
            CreatedDate = DateTime.Now
        }
    };

    var rooms = new List<Room>
    {
        new Room
        {
            HotelId = 1,
            RoomNumber = "101",
            RoomType = "Single",
            PricePerNight = 150m,
            MaxGuests = 1,
            Description = "Pokój jednoosobowy ze wspólną łazienką",
            Status = "Available",
            CreatedDate = DateTime.Now
        },
        new Room
        {
            HotelId = 1,
            RoomNumber = "102",
            RoomType = "Double",
            PricePerNight = 250m,
            MaxGuests = 2,
            Description = "Pokój dwuosobowy z prywatną łazienką",
            Status = "Available",
            CreatedDate = DateTime.Now
        },
        new Room
        {
            HotelId = 1,
            RoomNumber = "201",
            RoomType = "Suite",
            PricePerNight = 500m,
            MaxGuests = 4,
            Description = "Luksusowy apartament z salonem",
            Status = "Available",
            CreatedDate = DateTime.Now
        },
        new Room
        {
            HotelId = 2,
            RoomNumber = "1",
            RoomType = "Single",
            PricePerNight = 50m,
            MaxGuests = 1,
            Description = "Prosty pokój jednoosobowy",
            Status = "Available",
            CreatedDate = DateTime.Now
        },
        new Room
        {
            HotelId = 2,
            RoomNumber = "2",
            RoomType = "Double",
            PricePerNight = 80m,
            MaxGuests = 2,
            Description = "Pokój dwuosobowy",
            Status = "Available",
            CreatedDate = DateTime.Now
        }
    };

    context.Hotels.AddRange(hotels);
    context.Rooms.AddRange(rooms);
    context.SaveChanges();
}
